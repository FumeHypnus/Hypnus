#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <string.h>
int main(){
    int fd=socket(AF_INET,SOCK_STREAM,0);
    if(fd==-1){
        printf("socket error");
    }
   struct sockaddr_in server_addr;
   server_addr.sin_addr.s_addr=INADDR_ANY;
   server_addr.sin_family=AF_INET;
   server_addr.sin_port=htons(9999);
   int bi=bind(fd,(struct sockaddr*)&server_addr,sizeof(server_addr));
   if (bi==-1){
     printf("bind error");
     exit(1);
   }
   int li=listen(fd,128);
   if (li==-1){
     printf("listen error");
     exit(1);
   }
   struct sockaddr_in client_addr;
   memset(&client_addr,0,sizeof(client_addr));
   int len =sizeof(client_addr);
   int cfd=0;
   while(1){
    cfd=accept(fd,(struct sockaddr*)&client_addr,&len);
    if(cfd==-1){
        printf("accept error");
        exit(1);
    }
    // char buff[1024];
    // send(cfd,buff,strlen(buff),0);
    // recv(cfd,buff,sizeof(buff),0);
     char ip[32];
        printf("client ip:%s,client port:%d\n",inet_ntop(AF_INET,&client_addr.sin_addr.s_addr,ip,sizeof(ip)),ntohs(client_addr.sin_port));
        char buff[1024];
        sprintf(buff,"Hello, MUST, My StuID is 5240000545!\n");
        send(cfd,buff,strlen(buff)+1,0);
        memset(buff,0,sizeof(buff));
  while(1){
        int len =recv(cfd,buff,sizeof(buff),0);
        if (len>0){
            printf("client say;%s\n",buff);
            //send (cfd,buff+1,len,0);
        }else if(len==0){
            printf("client lost connect");
           
        }else if(len==-1){
            printf("recv error");
        } 
        if(strcmp("byebye",buff)== 0){//break
             memset(buff,0,sizeof(buff));
             
            break;
        } 
        memset(buff,0,sizeof(buff));
        printf("what do you want to say to client:");
        gets(buff);//scanf("%s",buff);
        send(cfd,buff,strlen(buff)+1,0);
        if(strcmp("byebye",buff)== 0){//break
             memset(buff,0,sizeof(buff));
             
            break;
        }
        memset(buff,0,sizeof(buff));
        
  }
  //close(cfd);
   }
      getchar();
    getchar();
    close(fd);
    close(cfd);
    
   
    return 0;
}