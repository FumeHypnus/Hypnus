#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <string.h>
int main(){
    //1.创建通信套接字
    int fd =socket(AF_INET,SOCK_STREAM,0);
    if(fd ==-1){
        printf("socket error");
        exit(1);
    }
    //2.绑定本地的ip port
    struct sockaddr_in serv_addr;
    serv_addr.sin_family= AF_INET;//对结构体进行初始化
    serv_addr.sin_port=htons(9999);//服务器绑定的是9999端口
    //客户端连接的时候也要去连接客户端端口
    inet_pton(AF_INET,"127.0.0.1",&serv_addr.sin_addr.s_addr);//我要进行远程连接所以我要去进行绑定一个ip
    //inet_pton这是转换ip的字节序并存储到sockaddr——里面
   //serv_addr.sin_addr.s_addr=INADDR_ANY;//这是一个宏 实际值为0不用大小端转换，
    //绑定0地址会自动读写并绑定比较灵活 本地连接用127.0.0.1
    int ret = connect(fd,(struct sockaddr *)&serv_addr,sizeof(serv_addr));//第一个参数是用于通信的套接字
    //第二个参数是我们要去连接哪一个ip和端口
    //第三个参数该ip和端口的长度
    if(ret == -1){
         printf("connect error\n");
        exit(1);
    }
    //通信
    while(1){
        //发送数据
        char buff[1024];
        sprintf(buff,"Hello, MUST, My StuID is 5240000545!");
        send(fd,buff,strlen(buff)+1,0);
        //接受数据
        memset(buff,0,sizeof(buff));
        int len =recv(fd,buff,sizeof(buff),0);
          //第一个是用于通信的文件标识符 第二个 是指向一块有效的内存 第三个是该内存的长度 第二个和第三个都是传出参数 第四个指定为0    
        if (len>0){
            printf("server say;%s\n",buff);
        }else if(len==0){
            printf("server lost connect");
            break;
        }else if(len==-1){
            printf("recv error");
            break;
        }
        sleep(10);
    }
    //通信，结束关闭文件描述符
    close(fd);
    return 0;
}