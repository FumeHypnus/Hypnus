#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <string.h>
int main(){
    int fd = socket(AF_INET,SOCK_STREAM,0);
    if(fd ==-1){
        printf("socket error");
        exit(1);
    }
    struct sockaddr_in client_addr;
    client_addr.sin_family=AF_INET;
    client_addr.sin_port=htons(9999);
    inet_pton(AF_INET,"192.168.1.108",&client_addr.sin_addr.s_addr);//use my ip
    int co=connect(fd,(struct sockaddr*)&client_addr,sizeof(client_addr));
     if(co ==-1){
        printf("connect error");
        exit(1);

    }
        char buff[1024];
        // sprintf(buff,"this is client1 connect with you");
        // send(fd,buff,strlen(buff)+1,0);
        // memset(buff,0,sizeof(buff));
        //sprintf(buff,"Hello, MUST, My StuID is 5240000545!");
        //send(fd,buff,strlen(buff)+1,0);
       while(1){
        memset(buff,0,sizeof(buff));

        int len =recv(fd,buff,sizeof(buff),0);
        if (len>0){
            printf("server say;%s\n",buff);
        }else if(len==0){
            printf("server lost connect");
           
        }else if(len==-1){
            printf("recv error");
           
        }if(strcmp("byebye",buff)== 0){
             memset(buff,0,sizeof(buff));
             
            break;
        } 
        memset(buff,0,sizeof(buff));
        
        printf("what do you want to say to server");
        gets(buff);//scanf("%s",buff);
        send(fd,buff,strlen(buff)+1,0);
        if(strcmp("byebye",buff)== 0){
             memset(buff,0,sizeof(buff));
             
            break;
        }
        sleep(1);}

   getchar();
    getchar();
    close(fd);
    
    
    return 0;
    
}