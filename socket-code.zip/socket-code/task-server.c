#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <string.h>
int main(){
    //1.创建监听文件标识符
    int fd =socket(AF_INET,SOCK_STREAM,0);//第一个是地址族协议第二个+第三个是看要tcp还是udp 返回值为-1时候表示错误
    if(fd ==-1){
        printf("socket error");
        exit(1);
    }
    struct sockaddr_in serv_addr;//这是一个结构体
    serv_addr.sin_family= AF_INET;//地址族协议
    serv_addr.sin_port=htons(9999);//h to s host to 将主机的小端字节序转换成网络的大端字节序
    serv_addr.sin_addr.s_addr=INADDR_ANY;//这是一个宏 会自动找到本机的ip
    int ret = bind(fd,(struct sockaddr *)&serv_addr,sizeof(serv_addr));//bind函数是将文件标识符绑定到一个端口上去监听
    //第一个是要绑定的文件标识符 第二个是绑定的ip和端口 先用sockaddr_in来初始化方便然后强制类型转换，第三个是socker_addr的长度方便读地址
    if(ret == -1){
         printf("bind error\n"); 
        exit(1);
    }
    ret = listen(fd, 128);//启动监听 第一个是监听的文件标识符 第二个是该监听函数listen一次性可以监听多少个
     if(ret == -1){
         printf("listen error\n");
        exit(1);
    }
    struct sockaddr_in caddr;//创建一个新的文件标识符
    int addrlen= sizeof(caddr);//查看文件标识符的长度
    int cfd = accept(fd,(struct sockaddr *)&caddr,&addrlen);//接受函数 首先在未接受connect的时候会一直阻塞
    //第一个参数是监听文件标识符通过bind绑定了ip和端口。
    //第二个参数是用于通信的文件标识符,目前里面没有东西,作为传出函数，
    //第三个参数是长度 是传入传出参数 会记录后面接受到的文件标识符的长度 注意这里是指针
     if(cfd == -1){
         printf("accept error\n");
        exit(1);
    }
    char ip[32];
        printf("client ip： %s, port: %d\n",inet_ntop(AF_INET,&caddr.sin_addr.s_addr,ip,sizeof(ip)),ntohs(caddr.sin_port));
        char buff[1024];
        sprintf(buff,"Hello, MUST, My StuID is 5240000545!");
        send(cfd,buff,strlen(buff)+1,0);//发送函数 第一个参数是ACCEPT的返回值 是那个用于通信的文件描述符  第二个是一个指针指向一块有效的内存
        //第三个参数是内存的大小+1是将\0也发送出去 第四个参数用0就可以。
        memset(buff,0,sizeof(buff));
  while(1){
   
        
        int len =recv(cfd,buff,sizeof(buff),0);
        if (len>0){
            
            printf("client say;%s\n",buff);
            //send (cfd,buff+1,len,0);
        }else if(len==0){
            printf("client lost connect");
           
        }else if(len==-1){
            printf("recv error");
        } 
        if(strcmp("byebye",buff)== 0){//break
             memset(buff,0,sizeof(buff));
             
            break;
        } 
        memset(buff,0,sizeof(buff));
        printf("what do you want to say to client:");
        scanf("%s",buff);
        send(cfd,buff,strlen(buff)+1,0);
        if(strcmp("byebye",buff)== 0){//break
             memset(buff,0,sizeof(buff));
             
            break;
        }
        memset(buff,0,sizeof(buff));
  }
      getchar();
    getchar();
    close(fd);
    close(cfd);
   
    return 0;
}