#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <string.h>
int main(){
    int serv_sock;
    struct sockaddr_in serv_addr;
    memset(&serv_addr,0,sizeof(serv_addr));//是在一段内存块中填充某个给定的值，它是对较大的结构体或数组进行清零操作的一种最快方法
    serv_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    if(serv_addr.sin_addr.s_addr == INADDR_NONE){
        printf("inet_aton error\n");
        exit(1);
    }
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port =htons(1234);
    serv_sock = socket(AF_INET,SOCK_STREAM,0);
    if(serv_sock == -1){
        printf("socket error\n");
        exit(1);
    }
   printf("socket id %d",serv_sock);
   if(bind(serv_sock,(struct sockaddr *)&serv_addr, sizeof(serv_addr) )== -1){
        printf("bind error\n");
        exit(1);
    
   }
   return 0;

}