#include<stdio.h>
int main(){
    int n=0;
    scanf("%d",&n);
    int m=n+1;
    int sum=m*(m+1)-2;
    int i=0;
    int flag=1;
    int q=0;
    for(i=0;i<sum;i++){
        if(flag==1){
            q++;
        printf("%d",i%10);
        if(q==m){
            printf("\n",m);
            q=0;
            m=m-1;
        }
		}
        if(m==0){
            flag=0;
           // printf("\n",m);
            q=0;
            m=2;
        }
        if(flag==0){
        	q++;
        	printf("%d",(i+1)%10);
             if(q==m){
            printf("\n",m);
            q=0;
            m++;
        }
        }
        
        
    }
    getchar();
     getchar();
    return 0;
}
