#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <string.h>
int main()
{
    pid_t pid;
    int lval=20;
    int gval=20;
    gval++,lval+=5;
    printf("orig:[%d,%d]\n",gval,lval);
}