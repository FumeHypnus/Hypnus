#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <string.h>
int main(){
    int fd=socket(AF_INET,SOCK_DGRAM,0);
     if(fd ==-1){
        printf("socket error");
        exit(1);
    }
    struct sockaddr_in server_addr;
    server_addr.sin_family=AF_INET;
     server_addr.sin_port=htons(6666);
    server_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    
   
    int bi=bind(fd,(struct sockaddr*)&server_addr,sizeof(server_addr));
    if (bi==-1){
     printf("bind error");
     exit(1);
   }
    char buffer[512];
    memset(buffer,0,sizeof(buffer));
    struct sockaddr_in re_addr;
    socklen_t len = sizeof(re_addr);
    while(1){
        int rec=recvfrom(fd,buffer,sizeof(buffer),0,(struct sockaddr*)&re_addr,&len);
         if(rec>0){
        printf("server say;%s\n",buffer);
        if(strcmp("byebye",buffer)== 0){
             memset(buffer,0,sizeof(buffer));
             
            break;
        }
    memset(buffer,0,sizeof(buffer));
    }
        memset(buffer,0,sizeof(buffer));
        printf("what do you want to say client:");
        gets(buffer);
        sendto(fd,buffer,strlen(buffer),0,(struct sockaddr*)&re_addr,sizeof(re_addr));
        if(strcmp("byebye",buffer)== 0){
             memset(buffer,0,sizeof(buffer));
             
            break;
        }
        memset(buffer,0,sizeof(buffer));}
        getchar();
        getchar();
    return 0;
}