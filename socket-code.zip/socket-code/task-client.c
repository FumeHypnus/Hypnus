#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <string.h>
int main(){
    int fd =socket(AF_INET,SOCK_STREAM,0);
    if(fd ==-1){
        printf("socket error");
        exit(1);
    }
    struct sockaddr_in serv_addr;
    serv_addr.sin_family= AF_INET;
    serv_addr.sin_port=htons(9999);

    inet_pton(AF_INET,"127.0.0.1",&serv_addr.sin_addr.s_addr);
   //serv_addr.sin_addr.s_addr=INADDR_ANY;
    int ret = connect(fd,(struct sockaddr *)&serv_addr,sizeof(serv_addr));
    if(ret == -1){
         printf("connect error\n");
        exit(1);
    }
  
   
     
        char buff[1024];
        //sprintf(buff,"Hello, MUST, My StuID is 5240000545!");
        //send(fd,buff,strlen(buff)+1,0);
       while(1){
        memset(buff,0,sizeof(buff));
        int len =recv(fd,buff,sizeof(buff),0);
        if (len>0){
            printf("server say;%s\n",buff);
        }else if(len==0){
            printf("server lost connect");
           
        }else if(len==-1){
            printf("recv error");
           
        }if(strcmp("byebye",buff)== 0){
             memset(buff,0,sizeof(buff));
             
            break;
        } 
        memset(buff,0,sizeof(buff));
        printf("what do you want to say to server");
        scanf("%s",buff);
        send(fd,buff,strlen(buff)+1,0);
        if(strcmp("byebye",buff)== 0){
             memset(buff,0,sizeof(buff));
             
            break;
        }
        sleep(1);}

   getchar();
    getchar();
    close(fd);
    
    
    return 0;
}