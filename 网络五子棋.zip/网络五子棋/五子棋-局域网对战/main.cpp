#pragma warning(disable:6031)
#pragma warning(disable:6054)
#pragma warning(disable:6385)

#include <stdio.h>
#include <WinSock2.h>
#include <WS2tcpip.h>
#pragma comment(lib,"ws2_32.lib")
#include <windows.h>
#include <easyx.h>

#define WWidth					640	//���ڿ���
#define WHeight					750	//���ڸ߶�
#define GHeight					640	//��Ϸ����߶�
#define BWidth					140	//��ť�������
#define PieceRadius				18	//���ӵİ뾶
#define FlushCount				10

struct Node
{
	int x;
	int y;
	int P;
	struct Node* LAST;
	struct Node* NEXT;
};

int ret = 0;
int Map[15][15];
int Position = 0;
int PX, PY;
char RecvBuffer[256];
char SendBufferX[256];
char SendBufferY[256];
BOOL GameOver = FALSE;
BOOL ISLAUNCH = FALSE;				//�Լ��Ƿ�����
Node* HEAD, * _END;


BOOL InitCheckerBoard()
{
	for (int i = 0; i < 15; i++)
		for (int j = 0; j < 15; j++)
			Map[i][j] = 0;
	HEAD = (Node*)malloc(sizeof(Node));
	_END = (Node*)malloc(sizeof(Node));
	if (HEAD == NULL || _END == NULL)
		return FALSE;
	HEAD->NEXT = _END;
	_END->LAST = HEAD;
	return TRUE;
}

BOOL AddNewNode(int x, int y, int p)
{
	Node* P = _END->LAST, * Q = _END;
	Node* N = (Node*)malloc(sizeof(Node));
	if (N == NULL)
		return FALSE;
	N->x = x;
	N->y = y;
	N->P = p;
	N->LAST = P;
	N->NEXT = Q;
	P->NEXT = N;
	Q->LAST = N;
	return TRUE;
}

void DrawBoardAndPiece()//�滭��������
{
	clearrectangle(0, 0, WWidth, GHeight);
	setfillcolor(RGB(105, 105, 105));
	fillrectangle(0, 0, WWidth, GHeight);
	for (int i = 0; i < 15; i++)
	{
		line(40 + 40 * i, 40, 40 + 40 * i, GHeight - 40);
		line(40, 40 + 40 * i, WWidth - 40, 40 + 40 * i);
	}
	setfillcolor(WHITE);
	fillcircle(160, 160, 5);
	fillcircle(480, 160, 5);
	fillcircle(320, 320, 5);
	fillcircle(160, 480, 5);
	fillcircle(480, 480, 5);
	for (int j = 0; j < 15; j++)
		for (int k = 0; k < 15; k++)
			if (Map[j][k] == 1)
			{
				setfillcolor(WHITE);
				fillcircle(40 + 40 * k, 40 + 40 * j, PieceRadius);
			}
			else if (Map[j][k] == -1)
			{
				setfillcolor(BLACK);
				fillcircle(40 + 40 * k, 40 + 40 * j, PieceRadius);
			}
}

BOOL GetInput(int MX, int MY, UINT UMSG)
{
	if (MX < 20 || MX > WWidth || MY < 20 || MY > GHeight)
		return FALSE;
	if (UMSG == WM_LBUTTONDOWN)
	{
		int x = (MX - 20) / 40;
		int y = (MY - 20) / 40;
		if (x < 0 || y < 0)
			return FALSE;
		if (Map[y][x] == 0)
		{
			Map[y][x] = Position;
			PX = y;
			PY = x;
			sprintf(SendBufferX, "%d", y);
			sprintf(SendBufferY, "%d", x);
			AddNewNode(y, x, Position);
			ISLAUNCH = TRUE;
			return TRUE;
		}
	}
	return FALSE;
}

void DrawSystemInfo()
{
	clearrectangle(BWidth + 1, GHeight + 1, WWidth, WHeight);
	settextstyle(20, 0, "����");
	outtextxy(BWidth + 10, GHeight + 45, RecvBuffer);
	return;
}

int DrawButton(int MX, int MY, UINT UMSG)//�滭��ť��ϵͳ֪ͨ��
{
	settextstyle(30, 0, "����");
	settextcolor(WHITE);
	outtextxy(30, GHeight + 20, "�ط�");
	outtextxy(30, GHeight + 60, "�˳�");
	if (MX > 30 && MX < 90 && MY > GHeight + 20 && MY < GHeight + 50)
	{
		settextcolor(RED);
		outtextxy(30, GHeight + 20, "�ط�");
		if (UMSG == WM_LBUTTONDOWN)
		{
			return 1;
		}
	}
	else if (MX > 30 && MX < 90 && MY > GHeight + 60 && GHeight + 90)
	{
		settextcolor(RED);
		outtextxy(30, GHeight + 60, "�˳�");
		if (UMSG == WM_LBUTTONDOWN)
		{
			return -1;
		}
	}
	return 0;
}

BOOL CaculateResult()
{
	for(int i = 2;i<=12;i++)
		for (int j = 2; j <= 12; j++)
		{
			if (Map[i][j] != 0 && Map[i][j] == Map[i][j - 1] && Map[i][j] == Map[i][j - 2] && Map[i][j] == Map[i][j + 1] && Map[i][j] == Map[i][j + 2])
			{
				GameOver = TRUE;
				return TRUE;
			}
			if (Map[i][j] != 0 && Map[i][j] == Map[i - 1][j] && Map[i][j] == Map[i - 2][j] && Map[i][j] == Map[i + 1][j] && Map[i][j] == Map[i + 2][j])
			{
				GameOver = TRUE;
				return TRUE;
			}
			if (Map[i][j] != 0 && Map[i][j] == Map[i - 1][j - 1] && Map[i][j] == Map[i - 2][j - 2] && Map[i][j] == Map[i + 1][j + 1] && Map[i][j] == Map[i + 2][j + 2])
			{
				GameOver = TRUE;
				return TRUE;
			}
			if (Map[i][j] != 0 && Map[i][j] == Map[i + 1][j - 1] && Map[i][j] == Map[i + 2][j - 2] && Map[i][j] == Map[i - 1][j + 1] && Map[i][j] == Map[i - 2][j + 2])
			{
				GameOver = TRUE;
				return TRUE;
			}
		}
	return FALSE;
}

void RePlay()
{
	clearrectangle(0, 0, WWidth, GHeight);
	setfillcolor(RGB(105, 105, 105));
	fillrectangle(0, 0, WWidth, GHeight);
	for (int i = 0; i < 15; i++)
	{
		line(40 + 40 * i, 40, 40 + 40 * i, GHeight - 40);
		line(40, 40 + 40 * i, WWidth - 40, 40 + 40 * i);
	}
	Node* N = HEAD->NEXT;
	while (N != _END)
	{
		if (N->P == 1)
		{
			setfillcolor(WHITE);
			fillcircle(40 + 40 * N->y, 40 + 40 * N->x, PieceRadius);
		}
		else
		{
			setfillcolor(BLACK);
			fillcircle(40 + 40 * N->y, 40 + 40 * N->x, PieceRadius);
		}
		N = N->NEXT;
		FlushBatchDraw();
		Sleep(800);
	}
}

int main()
{
	//1 ȷ��Э��汾
	WSADATA wsaData;
	WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (LOBYTE(wsaData.wVersion) != 2 || HIBYTE(wsaData.wVersion) != 2) 
	{
		printf("ȷ��Э��汾ʧ��!\n");
		return -1;
	}
	printf("ȷ��Э��汾�ɹ�!\n");

	//2 ����socket
	SOCKET serverSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (SOCKET_ERROR == serverSocket)
	{
		printf("����socketʧ��:%d\n", GetLastError());
		//9 ����Э��汾��Ϣ
		WSACleanup();
		return -1;
	}
	printf("����socket�ɹ�!\n");

	//3 ��ȡ������Э���ַ��
	SOCKADDR_IN addr = { 0 };
	addr.sin_family = AF_INET;//Э���ַ��
	addr.sin_addr.S_un.S_addr = inet_addr("115.198.209.166");//������д������IP��ַ
	addr.sin_port = htons(9527);//�������Ķ˿�

	//4 ���ӷ�����
	ret = connect(serverSocket, (sockaddr*)&addr, sizeof addr);
	if (ret == -1) 
	{
		printf("���ӷ�����ʧ��:%d\n", GetLastError());
		//6 �ر�socket
		closesocket(serverSocket);
		//7 ����Э��汾��Ϣ
		WSACleanup();

		return -1;
	}
	printf("���ӷ������ɹ�!\n");

	ret = recv(serverSocket, RecvBuffer, 255, NULL);//���ж��Ǻڷ����ǰ׷�
	if (ret == 0)
		return -1;
	RecvBuffer[ret] = '\0';

	Position = 1;//Ĭ���Լ�����
	ISLAUNCH = FALSE;//���־�û������
	if (strcmp(RecvBuffer, "-1") == 0)//�ж��Լ����ֻ��պ���
	{
		Position = -1;
		ISLAUNCH = TRUE;
	}

	ret = recv(serverSocket, RecvBuffer, 255, NULL);
	if (ret == 0)
		return -1;
	RecvBuffer[ret] = '\0';
	BOOL ISPOST = TRUE;
	if (Position == 1)
		ISPOST = FALSE;

	if (!InitCheckerBoard())
		return -1;
	HWND hwnd = initgraph(WWidth, WHeight, 0);
	SetWindowTextA(hwnd, "������");
	setlinecolor(WHITE);
	MOUSEMSG m = { 0 };
	BeginBatchDraw();
	while (!GameOver)
	{
		if (MouseHit())
			m = GetMouseMsg();
		DrawBoardAndPiece();
		DrawSystemInfo();
		FlushBatchDraw();
		if (!ISPOST)//�ж��Լ��Ƿ�������
		{
			ret = recv(serverSocket, RecvBuffer, 255, NULL);//��ȡ��������������Ϣ
			if (ret == 0)
				return -1;
			RecvBuffer[ret] = '\0';
			DrawSystemInfo();
			FlushBatchDraw();
			ISPOST = TRUE;
		}
		if (!ISLAUNCH && GetInput(m.x, m.y, m.uMsg))//���û�����Ӿͻ�ȡ���ӵ�
		{
			DrawBoardAndPiece();
			FlushBatchDraw();
			if (CaculateResult())
			{
				sprintf(RecvBuffer, "%d-%d-GameOver+", PX, PY);
				send(serverSocket, RecvBuffer, 255, NULL);
				sprintf(RecvBuffer, "������ʤ��");
			}
			else
			{
				sprintf(RecvBuffer, "%d-%d-Continue+", PX, PY); 
				send(serverSocket, RecvBuffer, 255, NULL);
				sprintf(RecvBuffer, "�ֵ��Է�����");
			}
			DrawSystemInfo();
			FlushBatchDraw();
		}
		if (ISLAUNCH && !GameOver)
		{
			ret = recv(serverSocket, RecvBuffer, 255, NULL);//���նԷ�����X
			if (ret == 0)
				return -1;
			RecvBuffer[ret] = '\0';
			int num = 0;
			char result[10];
			for (; num < ret; num++)
				if (RecvBuffer[num] != '-')
				{
					SendBufferX[num] = RecvBuffer[num];
				}
				else
				{
					SendBufferX[num] = '\0';
					break;
				}
			int numL = num + 1;
			for(num = num + 1;num<ret;num++)
				if (RecvBuffer[num] != '-')
				{
					SendBufferY[num - numL] = RecvBuffer[num];
				}
				else
				{
					SendBufferY[num - numL] = '\0';
					break;
				}
			numL = num + 1;
			for(num = num + 1;num < ret;num++)
				if (RecvBuffer[num] != '+')
				{
					result[num - numL] = RecvBuffer[num];
				}
				else
				{
					result[num - numL] = '\0';
					break;
				}
			int x = atoi(SendBufferX);
			int y = atoi(SendBufferY);
			Map[x][y] = (-1) * Position;
			AddNewNode(x, y, (-1) * Position);
			if (strcmp(result, "GameOver") == 0)
			{
				GameOver = TRUE;
				sprintf(RecvBuffer, "��Ϸ�������Է���ʤ��");
			}
			else
				sprintf(RecvBuffer, "�ֵ���������");
			DrawBoardAndPiece();
			DrawSystemInfo();
			FlushBatchDraw();
			ISLAUNCH = FALSE;
		}
		DrawBoardAndPiece();
		DrawSystemInfo();
		FlushBatchDraw();
	}
	while (GameOver)
	{
		if (MouseHit())
			m = GetMouseMsg();
		ret = DrawButton(m.x, m.y, m.uMsg);
		if (ret == 1)
			RePlay();//�ط�
		else if (ret == -1)
			break;
		FlushBatchDraw();
	}

	//6 �ر�socket
	closesocket(serverSocket);
	//7 ����Э��汾��Ϣ
	WSACleanup();
	return 0;

	
	return 0;
}